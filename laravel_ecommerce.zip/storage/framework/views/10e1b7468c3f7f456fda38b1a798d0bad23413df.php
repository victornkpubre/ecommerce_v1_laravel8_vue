<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\Laravel Projects\WebDev\php\laravel_ecommerce\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>